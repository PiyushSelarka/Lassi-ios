//
//  VideoPreviewVC.swift
//  MediaPicker
//
//  Created by mac-00015 on 03/06/19.
//  Copyright © 2019 mac-00015. All rights reserved.
//

import UIKit
import AVKit
import Photos

class VideoPreviewVC: UIViewController {
    
    @IBOutlet weak var sliderProgress: UISlider!
    @IBOutlet weak var lblCurrentTime: UILabel!
    @IBOutlet weak var lblRemainingTime: UILabel!
    @IBOutlet weak var btnPlayPause: UIButton!
    
    var videoURL: URL?
    var avPlayerVC = AVPlayerViewController()
    var player: AVPlayer?
    var playerLayer: AVPlayerLayer?
    var currentTime = Timer()
    var remainingTime = Timer()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.initialization()
    }
}

// MARK:- Initialization
// MARK:-
extension VideoPreviewVC {
    func initialization() {
        guard videoURL != nil else {
            return
        }
        playerLayer?.frame = self.view.frame
        playerLayer?.videoGravity = .resizeAspectFill
        player = AVPlayer(url: videoURL!)
        playerLayer = AVPlayerLayer(player: player)
        currentTime = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(checkCurrentTime), userInfo: nil, repeats: true)
        remainingTime = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(checkRemainingTime), userInfo: nil, repeats: true)
        playerLayer?.frame = CGRect(x: 0, y: 0, width: CScreenWidth, height: CScreenHeight)
        self.view.layer.insertSublayer(playerLayer!, at: 0)
        player?.play()
    }
}

// MARK:- Helper methods
// MARK:-
extension VideoPreviewVC {
    @objc func checkCurrentTime() {
        if let currentItem = player?.currentItem {
            let videoTotalTime = Float(CMTimeGetSeconds(currentItem.duration))
            let videoCurrentTime = Float(CMTimeGetSeconds(currentItem.currentTime()))
            let secondsFinal = lrintf(videoCurrentTime.truncatingRemainder(dividingBy: 60))
            let seconds = String(format: "%02d", Int(secondsFinal % 60))
            let minutes = String(format: "%02d", Int((videoCurrentTime.truncatingRemainder(dividingBy: 3600)) / 60))
            sliderProgress.value = videoCurrentTime / videoTotalTime
            self.actionAtEnd()
            lblCurrentTime.text = "\(minutes):\(seconds)"
        }
    }
    
    @objc func checkRemainingTime() {
        if let currentItem = player?.currentItem {
            let videoTotalTime = Float(CMTimeGetSeconds(currentItem.duration))
            let videoCurrentTime = Float(CMTimeGetSeconds(currentItem.currentTime()))
            let timeRemainingInVideo = videoTotalTime - videoCurrentTime
            let secondsFinal = lrintf(timeRemainingInVideo.truncatingRemainder(dividingBy: 60))
            let seconds = String(format: "%02d", Int(secondsFinal % 60))
            let minutes = String(format: "%02d", Int((timeRemainingInVideo.truncatingRemainder(dividingBy: 3600)) / 60))
            self.actionAtEnd()
            lblRemainingTime.text = "\(minutes):\(seconds)"
        }
    }
    
    fileprivate func customizeVideo() {
        player = AVPlayer(url: videoURL!)
        playerLayer = AVPlayerLayer(player: player)
    }
    
    fileprivate func actionAtEnd() {
        if sliderProgress.value == sliderProgress.maximumValue {
            btnPlayPause.setImage(UIImage(named: "play"), for: .normal)
            sliderProgress.value = 0.0
            btnPlayPause.tag = 1
        }
    }
}

// MARK:- Action Events
// MARK:-
extension VideoPreviewVC {
    @IBAction func btnCancelClicked(_ sender: UIButton) {
//        self.presentingViewController?.presentingViewController?.dismiss(animated: false, completion: nil)
        player?.pause()
        self.presentingViewController?.dismiss(animated: false, completion: nil)
    }
    
    @IBAction func btnRightClicked(_ sender: UIButton) {
        //...Need to save video to gallery
        UISaveVideoAtPathToSavedPhotosAlbum(videoURL?.path ?? "", nil, nil, nil)
        self.presentingViewController?.presentingViewController?.dismiss(animated: false, completion: nil)
        CGCDMainThread.async {
            AlbumsVC.shared.collVAlbums.reloadData()
        }
    }
    
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        player?.pause()
        guard let currentItem = player?.currentItem else {
            return
        }
        let videoTotalTime = CMTimeGetSeconds(currentItem.duration)
        let value = Float64(sender.value) * videoTotalTime
        let seekTime = CMTime(value: Int64(value), timescale: 1)
        player?.seek(to: seekTime, completionHandler: { (_) in
            self.player?.play()
        })
        self.actionAtEnd()
    }
    
    @IBAction func btnPlayPauseClicked(_ sender: UIButton) {
        if sender.tag == 0 {
            btnPlayPause.setImage(UIImage(named: "play"), for: .normal)
            player?.pause()
            sender.tag = 1
        } else {
            player?.play()
            sender.tag = 0
            btnPlayPause.setImage(UIImage(named: "pause"), for: .normal)
        }
    }
}
